
export type Category = 'Skincare' | 'Makeup' | 'Fragrance' | 'Service';

export interface Product {
  id: string;
  name: string;
  description: string;
  basePrice: number;
  price: number;
  category: Category;
  imageUrl: string;
  isService: boolean;
  rating?: number;
  reviewsCount?: number;
  badge?: string;
  ingredients?: string;
  usage?: string;
  origin?: string;
}

export interface AtelierUpdate {
  id: string;
  date: string;
  headline: string;
  content: string;
  isPriority: boolean;
}

export interface SiteModules {
  aiAdvisor: boolean;
  virtualTryOn: boolean;
  liveValuation: boolean;
  journal: boolean;
  newsletter: boolean;
}

export interface SiteConfig {
  announcement: string;
  heroHeadline: string;
  heroSubheadline: string;
  isLiveValuationEnabled: boolean;
  modules: SiteModules;
}

export interface Order {
  id: string;
  date: string;
  items: CartItem[];
  total: number;
  status: 'Processing' | 'Shipped' | 'Delivered';
}

export interface CartItem extends Product {
  quantity: number;
}

export enum View {
  SHOP = 'SHOP',
  SERVICES = 'SERVICES',
  ADMIN = 'ADMIN',
  CART = 'CART',
  EDSON_ADVISOR = 'EDSON_ADVISOR',
  PROFILE = 'PROFILE'
}
