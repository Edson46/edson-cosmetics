
import React, { useState, useEffect, useCallback } from 'react';
import { View, Product, CartItem, Order, SiteConfig, AtelierUpdate } from './types';
import { INITIAL_PRODUCTS, INITIAL_UPDATES } from './constants';
import Navbar from './components/Navbar';
import ProductCard from './components/ProductCard';
import AdminPanel from './components/AdminPanel';
import EdsonAdvisor from './components/AIConsultant'; 
import Cart from './components/Cart';
import Profile from './components/Profile';
import VirtualTryOn from './components/VirtualTryOn';
import QuickManifest from './components/QuickManifest';

const DEFAULT_CONFIG: SiteConfig = {
  announcement: "Complimentary Express Shipping on all orders over $250.",
  heroHeadline: "The Boutique",
  heroSubheadline: "Prices are meticulously calculated based on real-time global availability of rare botanical extracts.",
  isLiveValuationEnabled: true,
  modules: {
    aiAdvisor: true,
    virtualTryOn: true,
    liveValuation: true,
    journal: true,
    newsletter: true
  }
};

interface Toast {
  id: number;
  message: string;
  type: 'success' | 'error' | 'info';
}

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>(View.SHOP);
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [siteConfig, setSiteConfig] = useState<SiteConfig>(DEFAULT_CONFIG);
  const [atelierUpdates, setAtelierUpdates] = useState<AtelierUpdate[]>(INITIAL_UPDATES);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeVTO, setActiveVTO] = useState<Product | null>(null);
  const [showQuickManifest, setShowQuickManifest] = useState(false);
  const [isMasterAuthorized, setIsMasterAuthorized] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);

  useEffect(() => {
    const savedProducts = localStorage.getItem('edson_archive_products');
    if (savedProducts) setProducts(JSON.parse(savedProducts));
    
    const savedConfig = localStorage.getItem('edson_archive_config');
    if (savedConfig) setSiteConfig(JSON.parse(savedConfig));

    const savedUpdates = localStorage.getItem('edson_archive_updates');
    if (savedUpdates) setAtelierUpdates(JSON.parse(savedUpdates));

    const savedCart = localStorage.getItem('edson_archive_cart');
    if (savedCart) setCart(JSON.parse(savedCart));

    const savedOrders = localStorage.getItem('edson_archive_orders');
    if (savedOrders) setOrders(JSON.parse(savedOrders));
  }, []);

  const notify = useCallback((message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Date.now();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  }, []);

  useEffect(() => {
    if (!siteConfig.isLiveValuationEnabled || !siteConfig.modules.liveValuation) return;
    const interval = setInterval(() => {
      setProducts(prevProducts => prevProducts.map(p => {
        const volatility = p.isService ? 0.005 : 0.02; 
        const change = 1 + (Math.random() * volatility * 2 - volatility);
        const newPrice = Number((p.basePrice * change).toFixed(2));
        return { ...p, price: newPrice };
      }));
    }, 15000);
    return () => clearInterval(interval);
  }, [siteConfig.isLiveValuationEnabled, siteConfig.modules.liveValuation]);

  useEffect(() => { localStorage.setItem('edson_archive_products', JSON.stringify(products)); }, [products]);
  useEffect(() => { localStorage.setItem('edson_archive_config', JSON.stringify(siteConfig)); }, [siteConfig]);
  useEffect(() => { localStorage.setItem('edson_archive_updates', JSON.stringify(atelierUpdates)); }, [atelierUpdates]);
  useEffect(() => { localStorage.setItem('edson_archive_cart', JSON.stringify(cart)); }, [cart]);
  useEffect(() => { localStorage.setItem('edson_archive_orders', JSON.stringify(orders)); }, [orders]);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1, price: product.price } : item);
      return [...prev, { ...product, quantity: 1 }];
    });
    notify(`${product.name} ${product.isService ? 'scheduled' : 'added to selection'}.`);
  };

  const removeFromCart = (id: string) => setCart(prev => prev.filter(item => item.id !== id));
  const updateCartQty = (id: string, delta: number) => {
    setCart(prev => prev.map(item => item.id === id ? { ...item, quantity: Math.max(1, item.quantity + delta) } : item));
  };

  const handleCheckout = (newOrder: Order) => {
    setOrders(prev => [newOrder, ...prev]);
    setCart([]);
    notify("Your investment has been secured.", 'success');
  };

  const renderView = () => {
    switch (currentView) {
      case View.SHOP:
        const onlyProducts = products.filter(p => !p.isService);
        const trending = onlyProducts.slice(0, 3);
        const latestUpdate = atelierUpdates[0];
        return (
          <div className="animate-in fade-in duration-1000">
            {/* Hero Section with Feature Highlight */}
            <section className="relative h-[70vh] flex items-center justify-center overflow-hidden bg-stone-900 mb-20">
              <div className="absolute inset-0 opacity-40">
                <img src="https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?auto=format&fit=crop&q=80&w=2000" className="w-full h-full object-cover" alt="Luxury Background" />
              </div>
              <div className="absolute inset-0 bg-gradient-to-b from-stone-900/50 via-transparent to-stone-950"></div>
              <div className="relative text-center px-6 max-w-4xl">
                {latestUpdate && siteConfig.modules.journal && (
                  <div className="inline-flex items-center space-x-3 px-5 py-2 rounded-full border border-amber-500/30 bg-stone-950/80 mb-8 backdrop-blur-md">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                    </span>
                    <span className="text-[10px] font-bold text-amber-500 uppercase tracking-[0.3em]">Latest manifestation: {latestUpdate.headline}</span>
                  </div>
                )}
                <h1 className="text-7xl md:text-9xl font-bold text-white mb-6 serif tracking-tight drop-shadow-2xl">{siteConfig.heroHeadline}</h1>
                <p className="text-stone-300 italic text-xl md:text-2xl font-light leading-relaxed drop-shadow-lg">{siteConfig.heroSubheadline}</p>
              </div>
            </section>

            <div className="max-w-7xl mx-auto px-6 pb-20">
              {/* Features/Journal Section */}
              {atelierUpdates.length > 0 && siteConfig.modules.journal && (
                <section className="mb-32">
                  <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 border-b border-stone-100 pb-10">
                    <div>
                      <h2 className="text-[10px] uppercase tracking-[0.6em] font-bold text-amber-800 mb-3">Atelier Journal</h2>
                      <p className="text-4xl font-bold text-stone-900 serif italic">Boutique Intelligence & Updates</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
                    {atelierUpdates.slice(0, 3).map(update => (
                      <div key={update.id} className="group relative bg-white border border-stone-100 p-10 shadow-sm hover:shadow-2xl transition-all duration-500">
                        <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-100 transition-opacity">
                          <svg className="w-8 h-8 text-amber-800" fill="currentColor" viewBox="0 0 20 20"><path d="M10 2a8 8 0 100 16 8 8 0 000-16zM9 13a1 1 0 112 0 1 1 0 01-2 0zm1-9a1 1 0 011 1v5a1 1 0 11-2 0V5a1 1 0 011-1z"/></svg>
                        </div>
                        <p className="text-[9px] font-bold text-stone-300 uppercase tracking-widest mb-6 group-hover:text-amber-800 transition-colors">{update.date}</p>
                        <h3 className="text-2xl font-bold serif mb-6 leading-tight text-stone-900">{update.headline}</h3>
                        <p className="text-sm text-stone-500 italic leading-loose line-clamp-4">{update.content}</p>
                      </div>
                    ))}
                  </div>
                </section>
              )}

              {/* Product Grid */}
              <section className="mb-32">
                 <h2 className="text-[10px] uppercase tracking-[0.6em] font-bold text-stone-400 mb-16 text-center">Formulation Archive</h2>
                 {onlyProducts.length === 0 ? (
                   <div className="text-center py-40 border-2 border-dashed border-stone-100">
                     <p className="serif italic text-2xl text-stone-300">The vaults are currently sealed. Manifesting new collections soon.</p>
                   </div>
                 ) : (
                   <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12">
                     {onlyProducts.map(p => (
                       <ProductCard 
                         key={p.id} 
                         product={p} 
                         onAddToCart={addToCart} 
                         onTryOn={siteConfig.modules.virtualTryOn ? setActiveVTO : undefined}
                         showValuation={siteConfig.modules.liveValuation}
                       />
                     ))}
                   </div>
                 )}
              </section>
            </div>
          </div>
        );
      case View.SERVICES:
        const services = products.filter(p => p.isService);
        return (
          <div className="max-w-7xl mx-auto py-32 px-6 animate-in fade-in duration-700">
            <header className="mb-24 text-center max-w-3xl mx-auto">
              <h1 className="text-7xl font-bold text-stone-900 mb-8 serif tracking-tight">Atelier Services</h1>
              <p className="text-stone-500 italic text-2xl font-light leading-relaxed">Experience bespoke transformations in the heart of our Paris sanctuary. Each ritual is tailored to your unique biological profile.</p>
            </header>
            {services.length === 0 ? (
              <div className="text-center py-40 bg-stone-50 border border-stone-100 italic serif text-stone-400 text-xl">
                The Master Formulator is currently fully committed.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-20">
                {services.map(p => (
                  <ProductCard key={p.id} product={p} onAddToCart={addToCart} showValuation={siteConfig.modules.liveValuation} />
                ))}
              </div>
            )}
          </div>
        );
      case View.ADMIN: 
        return <AdminPanel 
          products={products}
          onAddProduct={(p) => { setProducts(prev => [p, ...prev]); notify(`New formulation manifested: ${p.name}`); }} 
          onUpdateProduct={(id, u) => { setProducts(prev => prev.map(p => p.id === id ? { ...p, ...u } : p)); notify("Archive updated."); }}
          onDeleteProduct={(id) => { setProducts(prev => prev.filter(p => p.id !== id)); notify("Purged from archive.", 'info'); }}
          updates={atelierUpdates}
          onAddUpdate={(u) => { setAtelierUpdates(prev => [u, ...prev]); notify("New site feature announced."); }}
          onDeleteUpdate={(id) => { setAtelierUpdates(prev => prev.filter(u => u.id !== id)); notify("Journal entry purged."); }}
          siteConfig={siteConfig}
          onUpdateConfig={(c) => { setSiteConfig(c); notify("Global configuration committed."); }}
          isMasterAuthorized={isMasterAuthorized}
          onSetMasterAuthorized={setIsMasterAuthorized}
        />;
      case View.EDSON_ADVISOR: return <EdsonAdvisor />;
      case View.CART: return <Cart items={cart} onRemove={removeFromCart} onUpdateQty={updateCartQty} onCheckout={handleCheckout} />;
      case View.PROFILE: return <Profile orders={orders} onMessageAtelier={() => setCurrentView(View.EDSON_ADVISOR)} />;
      default: return null;
    }
  };

  return (
    <div className="min-h-screen pb-20 selection:bg-amber-100 selection:text-amber-900 bg-[#faf9f6]">
      {/* Toast Notification Container */}
      <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[200] space-y-3 pointer-events-none">
        {toasts.map(toast => (
          <div key={toast.id} className="animate-in slide-in-from-top duration-500 pointer-events-auto">
            <div className={`px-8 py-4 shadow-2xl backdrop-blur-xl border border-white/20 rounded-sm flex items-center space-x-4 ${
              toast.type === 'success' ? 'bg-stone-900 text-amber-500' : 
              toast.type === 'error' ? 'bg-red-950 text-red-200' : 'bg-stone-100 text-stone-800'
            }`}>
              <span className="text-[10px] font-bold uppercase tracking-[0.2em]">{toast.message}</span>
            </div>
          </div>
        ))}
      </div>

      {siteConfig.announcement && (
        <div className="bg-stone-900 text-amber-500 py-3 text-center text-[10px] font-bold uppercase tracking-[0.5em] border-b border-amber-900/20 relative z-[60]">
          {siteConfig.announcement}
        </div>
      )}
      
      <Navbar 
        currentView={currentView} 
        setView={setCurrentView} 
        cartCount={cart.reduce((s, i) => s + i.quantity, 0)} 
        modules={siteConfig.modules}
      />
      
      <main>
        {renderView()}
      </main>

      {activeVTO && <VirtualTryOn productName={activeVTO.name} onClose={() => setActiveVTO(null)} />}

      {/* Concierge Trigger */}
      <a 
        href="https://wa.me/255621275922" 
        target="_blank" 
        rel="noopener noreferrer"
        className="fixed bottom-10 right-10 z-[60] bg-stone-950 text-amber-500 p-6 rounded-full shadow-[0_20px_60px_rgba(0,0,0,0.5)] border border-amber-800/30 hover:scale-110 hover:bg-amber-800 hover:text-white transition-all duration-300 group active:scale-95"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="currentColor">
          <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.417-.003 6.557-5.338 11.892-11.893 11.892-1.997-.001-3.951-.5-5.688-1.448l-6.305 1.652zm6.599-3.835c1.52.909 3.019 1.388 4.647 1.389 5.405 0 9.811-4.406 9.813-9.812.001-2.618-1.02-5.08-2.875-6.937-1.856-1.856-4.318-2.876-6.937-2.877-5.407 0-9.812 4.406-9.815 9.813-.001 1.738.464 3.43 1.345 4.904l-.997 3.639 3.719-.976zm11.323-6.405c-.279-.14-.1.649-.51.455-.409-.194-1.722-.633-2.422-1.258-.532-.474-.865-1.029-.97-1.209-.105-.18-.011-.277.079-.367.08-.081.18-.21.27-.315.09-.105.12-.18.18-.3.06-.12.03-.225-.015-.315-.045-.09-.405-1.02-.555-1.38-.145-.352-.292-.304-.405-.31l-.345-.006c-.12 0-.315.045-.48.225-.165.18-.63.615-.63 1.5s.645 1.74 1.335 1.86c.09.012.045.075.09.12.36.36 2.112 3.232 5.112 4.522.714.307 1.27.49 1.703.627.717.227 1.37.195 1.887.118.577-.087 1.777-.726 2.025-1.425.247-.699.247-1.299.172-1.425-.075-.126-.27-.195-.548-.335z"/>
        </svg>
      </a>

      <footer className="py-40 border-t border-stone-200 mt-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-24">
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-5 mb-12">
              <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-amber-800 shadow-2xl">
                <img src="https://raw.githubusercontent.com/fedelebron/edson-assets/main/edson-founder.jpg" className="w-full h-full object-cover object-top grayscale-[0.2]" alt="Edson Founder" />
              </div>
              <div className="text-4xl font-bold tracking-tighter text-stone-900">
                <span className="text-amber-800">EDSON</span><span className="font-light">COSMETICS</span>
              </div>
            </div>
            <p className="text-stone-500 text-sm leading-relaxed italic max-w-xs">Purveyors of rare biological extracts, synthetic elegance, and eternal brilliance since 1994. Paris • London • Tokyo.</p>
          </div>
          
          <div className="lg:col-span-2 flex flex-col items-center">
            <h4 className="text-[11px] uppercase tracking-[0.6em] font-bold text-stone-900 mb-12">Insider Registration</h4>
            <div className="w-full max-w-md">
               <div className="flex border-b border-stone-300 pb-3 group">
                 <input placeholder="Enter your private email..." className="bg-transparent py-4 text-base focus:outline-none flex-grow italic placeholder:text-stone-300" />
                 <button className="text-amber-800 uppercase tracking-widest text-[11px] font-bold hover:text-stone-900 transition-colors px-6">Submit</button>
               </div>
               <p className="text-[9px] text-stone-400 mt-6 uppercase tracking-widest text-center">Inscribing ensures you are first to witness new site manifests.</p>
            </div>
          </div>

          <div className="text-right">
            <div className="text-6xl font-bold tracking-[0.3em] text-stone-100 mb-8 select-none">EDSON</div>
            <p className="text-[11px] text-stone-500 uppercase tracking-[0.5em] font-bold mb-6">Founder & CEO</p>
            <a href="https://wa.me/255621275922" className="text-[12px] text-amber-800 font-bold uppercase tracking-[0.3em] hover:text-stone-900 transition-colors flex items-center justify-end space-x-3">
              <span>Contact Concierge</span>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M17 8l4 4m0 0l-4 4m4-4H3" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"/></svg>
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
