
import React, { useState } from 'react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onTryOn?: (product: Product) => void;
  showValuation?: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart, onTryOn, showValuation = true }) => {
  const [isAdded, setIsAdded] = useState(false);
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const isHigher = product.price > product.basePrice;
  const isLower = product.price < product.basePrice;

  const handleAdd = () => {
    onAddToCart(product);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  const toggleSection = (section: string) => {
    setActiveSection(activeSection === section ? null : section);
  };

  const sections = [
    { id: 'ingredients', label: 'Ingredients', content: product.ingredients || "Proprietary blend of active biological extracts and rare minerals." },
    { id: 'usage', label: 'Ritual', content: product.usage || "Apply sparingly to the target area using rhythmic motions to stimulate absorption." },
    { id: 'origin', label: 'Provenance', content: product.origin || "Ethically harvested and synthesized in our specialized European ateliers." }
  ];

  return (
    <div className="group flex flex-col h-full bg-white overflow-hidden transition-all duration-300 shadow-sm hover:shadow-xl border border-stone-100">
      <div className="relative aspect-[4/5] overflow-hidden bg-stone-100">
        {product.badge && (
          <span className="absolute top-4 left-4 z-10 bg-amber-800 text-white text-[9px] font-bold uppercase tracking-widest px-3 py-1 shadow-lg">
            {product.badge}
          </span>
        )}
        <img 
          src={product.imageUrl} 
          alt={product.name} 
          className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-1000"
        />
        <div className="absolute inset-0 bg-stone-900/0 group-hover:bg-stone-900/20 transition-colors duration-500 flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 p-6 space-y-3">
          <button 
            onClick={handleAdd}
            className={`w-full py-3 text-[10px] font-bold uppercase tracking-widest shadow-2xl transform translate-y-4 group-hover:translate-y-0 transition-all duration-300 ${
              isAdded 
                ? 'bg-amber-800 text-white translate-y-0' 
                : 'bg-white text-stone-900 hover:bg-amber-800 hover:text-white'
            }`}
          >
            {isAdded ? (product.isService ? 'Ritual Scheduled ✓' : 'Item Manifested ✓') : (product.isService ? 'Schedule Ritual' : 'Add to Selection')}
          </button>
          {!product.isService && product.category === 'Makeup' && onTryOn && (
            <button 
              onClick={() => onTryOn(product)}
              className="w-full bg-stone-900/80 backdrop-blur-md text-white py-3 text-[10px] font-bold uppercase tracking-widest transform translate-y-4 group-hover:translate-y-0 transition-all duration-300 delay-75 hover:bg-stone-800"
            >
              Virtual Try-On
            </button>
          )}
        </div>
      </div>
      
      <div className="p-6 flex flex-col flex-grow border-t border-stone-50">
        <div className="flex justify-between items-start mb-2">
          <span className="text-[9px] uppercase tracking-[0.3em] text-stone-400 font-bold">{product.category}</span>
          <div className="flex flex-col items-end">
             <div className="flex items-center space-x-1">
                {showValuation && isHigher && <span className="text-[8px] text-green-600 animate-bounce">▲</span>}
                {showValuation && isLower && <span className="text-[8px] text-red-600 animate-bounce">▼</span>}
                <span className="text-sm font-semibold text-stone-900 tabular-nums">
                  ${product.price.toFixed(2)}
                </span>
             </div>
             {showValuation && <span className="text-[7px] uppercase tracking-tighter text-stone-300 font-bold">Live Valuation</span>}
          </div>
        </div>
        <h3 className="text-lg font-bold text-stone-900 mb-2 leading-tight group-hover:text-amber-800 transition-colors serif">{product.name}</h3>
        
        {product.rating && (
          <div className="flex items-center space-x-1 mb-3">
            <div className="flex text-amber-500 text-[10px]">
              {[...Array(5)].map((_, i) => (
                <span key={i}>{i < Math.floor(product.rating || 0) ? '★' : '☆'}</span>
              ))}
            </div>
            <span className="text-[10px] text-stone-400 font-medium">({product.reviewsCount})</span>
          </div>
        )}

        <p className="text-sm text-stone-500 line-clamp-2 leading-relaxed mb-6 italic">{product.description}</p>

        {/* Accordion Detail Section */}
        <div className="mt-auto border-t border-stone-50 pt-4 space-y-1">
          {sections.map((section) => (
            <div key={section.id} className="border-b border-stone-50 last:border-0">
              <button 
                onClick={() => toggleSection(section.id)}
                className="w-full flex justify-between items-center py-2 text-[9px] font-bold uppercase tracking-[0.2em] text-stone-400 hover:text-amber-800 transition-colors"
              >
                <span>{section.label}</span>
                <svg 
                  className={`w-3 h-3 transition-transform duration-500 ${activeSection === section.id ? 'rotate-180 text-amber-800' : ''}`} 
                  fill="none" viewBox="0 0 24 24" stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              <div className={`overflow-hidden transition-all duration-500 ${activeSection === section.id ? 'max-h-48 mb-4' : 'max-h-0'}`}>
                <p className="text-[11px] text-stone-500 italic leading-relaxed py-1">
                  {section.content}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
