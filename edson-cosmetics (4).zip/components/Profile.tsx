
import React from 'react';
import { Order } from '../types';

interface ProfileProps {
  orders: Order[];
  onMessageAtelier: () => void;
}

const Profile: React.FC<ProfileProps> = ({ orders, onMessageAtelier }) => {
  return (
    <div className="max-w-4xl mx-auto py-20 px-6">
      <div className="flex items-end space-x-8 mb-20">
        <div className="w-32 h-32 bg-stone-100 rounded-full flex items-center justify-center text-4xl text-stone-300 font-light border border-stone-200">
          ME
        </div>
        <div className="pb-4">
          <h2 className="text-4xl font-bold serif mb-2">Private Client</h2>
          <p className="text-stone-400 text-xs uppercase tracking-widest font-bold">Edson Membership: Platinum</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-12">
          <section>
            <h3 className="text-xs uppercase tracking-[0.4em] font-bold text-amber-800 mb-8 pb-2 border-b border-stone-100">Order History</h3>
            {orders.length === 0 ? (
              <p className="text-stone-400 italic text-sm">No orders found in our digital archives.</p>
            ) : (
              <div className="space-y-6">
                {orders.map(order => (
                  <div key={order.id} className="p-6 bg-white border border-stone-100 shadow-sm flex items-center justify-between">
                    <div>
                      <p className="text-xs font-bold text-stone-400 uppercase tracking-widest mb-1">Order #{order.id}</p>
                      <p className="text-lg serif italic">{order.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-stone-900 mb-1">${order.total.toFixed(2)}</p>
                      <span className={`text-[9px] uppercase tracking-widest font-bold px-2 py-1 ${
                        order.status === 'Shipped' ? 'bg-green-50 text-green-700' : 'bg-stone-50 text-stone-500'
                      }`}>
                        {order.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>

        <div className="space-y-8">
          <section className="bg-stone-900 p-8 text-white rounded-sm shadow-xl border border-amber-900/30">
            <h3 className="text-[10px] uppercase tracking-[0.3em] font-bold text-amber-500 mb-6">Concierge Support</h3>
            <p className="text-xs leading-relaxed text-stone-400 mb-6 italic">Connect directly with me or my digital shadow for bespoke ritual guidance.</p>
            <div className="space-y-3">
              <button 
                onClick={onMessageAtelier}
                className="w-full py-3 border border-white/20 text-[10px] font-bold uppercase tracking-widest hover:bg-white hover:text-black transition-all"
              >
                Edson Private Advisor
              </button>
              <a 
                href="https://wa.me/255621275922"
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full py-3 bg-amber-800 text-center text-white text-[10px] font-bold uppercase tracking-widest hover:bg-amber-700 transition-all shadow-lg"
              >
                Direct WhatsApp Line
              </a>
            </div>
          </section>

          <section className="bg-amber-50 p-8 border border-amber-100">
            <h3 className="text-[10px] uppercase tracking-[0.3em] font-bold text-amber-900 mb-4">Loyalty Status</h3>
            <p className="text-2xl serif text-amber-900 mb-1">2,450</p>
            <p className="text-[9px] text-amber-800 uppercase tracking-widest font-bold mb-4">Atelier Points</p>
            <div className="w-full bg-amber-200 h-1 rounded-full overflow-hidden">
              <div className="w-3/4 h-full bg-amber-800"></div>
            </div>
            <p className="text-[9px] text-amber-700 mt-2 font-medium">550 pts to your next exclusive gift</p>
          </section>
        </div>
      </div>
    </div>
  );
};

export default Profile;
