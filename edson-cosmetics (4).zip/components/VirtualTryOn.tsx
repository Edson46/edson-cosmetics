
import React, { useRef, useEffect, useState } from 'react';

interface VTOProps {
  productName: string;
  onClose: () => void;
}

const VirtualTryOn: React.FC<VTOProps> = ({ productName, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function startCamera() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err) {
        setError("Please grant camera access to use Virtual Try-On.");
      }
    }
    startCamera();
    return () => {
      if (videoRef.current?.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  return (
    <div className="fixed inset-0 z-[100] bg-stone-900 flex items-center justify-center p-4">
      <div className="relative w-full max-w-2xl bg-black rounded-3xl overflow-hidden shadow-2xl border border-stone-800">
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 z-10 bg-white/10 hover:bg-white/20 text-white p-3 rounded-full backdrop-blur-md transition-all"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"/></svg>
        </button>

        <div className="relative aspect-[3/4] bg-stone-800">
          {error ? (
            <div className="absolute inset-0 flex items-center justify-center text-center p-10">
              <p className="text-white/60 text-sm italic">{error}</p>
            </div>
          ) : (
            <>
              <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                className="w-full h-full object-cover grayscale-[0.2] contrast-[1.1]"
              />
              {/* Simulated Makeup Filter Overlay */}
              <div className="absolute inset-0 bg-red-900/10 mix-blend-multiply pointer-events-none animate-pulse"></div>
              <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/60 pointer-events-none"></div>
            </>
          )}
        </div>

        <div className="p-8 bg-stone-900 text-center">
          <p className="text-[10px] text-amber-500 uppercase tracking-[0.4em] font-bold mb-2">Live Demonstration</p>
          <h3 className="text-white text-xl serif italic mb-4">Experiencing: {productName}</h3>
          <p className="text-stone-400 text-xs px-12 leading-relaxed">Our AR engine is simulating the pigment intensity and texture on your specific skin tone.</p>
        </div>
      </div>
    </div>
  );
};

export default VirtualTryOn;
