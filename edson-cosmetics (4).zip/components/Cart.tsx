
import React, { useState } from 'react';
import { CartItem, Order } from '../types';

interface CartProps {
  items: CartItem[];
  onRemove: (id: string) => void;
  onUpdateQty: (id: string, delta: number) => void;
  onCheckout: (order: Order) => void;
}

const Cart: React.FC<CartProps> = ({ items, onRemove, onUpdateQty, onCheckout }) => {
  const [step, setStep] = useState<'cart' | 'payment' | 'processing' | 'success'>('cart');
  const [lastOrder, setLastOrder] = useState<Order | null>(null);
  const total = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const handlePayment = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('processing');
    
    setTimeout(() => {
      const newOrder: Order = {
        id: Math.random().toString(36).substr(2, 9).toUpperCase(),
        date: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
        items: [...items],
        total: total,
        status: 'Processing'
      };
      setLastOrder(newOrder);
      setStep('success');
      onCheckout(newOrder);
    }, 2500);
  };

  if (step === 'success' && lastOrder) {
    return (
      <div className="max-w-2xl mx-auto py-24 px-6 text-center animate-in fade-in zoom-in duration-700">
        <div className="w-20 h-20 bg-amber-800 text-white rounded-full flex items-center justify-center mx-auto mb-10 shadow-2xl">
          <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"/></svg>
        </div>
        <h2 className="text-5xl font-bold serif mb-4">A Grand Selection</h2>
        <p className="text-stone-500 italic mb-12">Thank you for choosing Edson. Your curation is being meticulously prepared.</p>
        
        <div className="bg-white border border-stone-100 p-10 text-left shadow-sm mb-12">
          <div className="flex justify-between border-b border-stone-50 pb-6 mb-6">
            <div>
              <p className="text-[10px] text-stone-400 uppercase tracking-widest font-bold mb-1">Receipt Number</p>
              <p className="text-lg serif">#{lastOrder.id}</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] text-stone-400 uppercase tracking-widest font-bold mb-1">Date</p>
              <p className="text-lg serif">{lastOrder.date}</p>
            </div>
          </div>
          <div className="space-y-4 mb-8">
            {lastOrder.items.map(item => (
              <div key={item.id} className="flex justify-between text-sm">
                <span className="text-stone-600">{item.quantity}x {item.name}</span>
                <span className="font-medium">${(item.price * item.quantity).toFixed(2)}</span>
              </div>
            ))}
          </div>
          <div className="flex justify-between pt-6 border-t border-stone-100 text-xl font-bold serif">
            <span>Total Invested</span>
            <span className="text-amber-800">${lastOrder.total.toFixed(2)}</span>
          </div>
        </div>
        
        <button 
          onClick={() => window.location.reload()}
          className="text-amber-800 text-xs uppercase tracking-[0.3em] font-bold hover:text-amber-900 transition-colors"
        >
          Back to the Boutique
        </button>
      </div>
    );
  }

  if (items.length === 0 && step === 'cart') {
    return (
      <div className="max-w-2xl mx-auto py-24 text-center">
        <h2 className="text-3xl font-bold mb-4 serif">Your Selection is Empty</h2>
        <p className="text-stone-500 mb-8">Discover our curated boutique to begin your beauty journey.</p>
      </div>
    );
  }

  if (step === 'processing') {
    return (
      <div className="max-w-2xl mx-auto py-32 text-center flex flex-col items-center">
        <div className="w-16 h-16 border-4 border-amber-800 border-t-transparent rounded-full animate-spin mb-8"></div>
        <h2 className="text-2xl font-bold serif mb-2">Securing Your Selection</h2>
        <p className="text-stone-500">Processing your secure payment through Edson Vault...</p>
      </div>
    );
  }

  if (step === 'payment') {
    return (
      <div className="max-w-xl mx-auto py-12 px-6">
        <button 
          onClick={() => setStep('cart')}
          className="text-stone-400 text-[10px] uppercase tracking-widest mb-8 hover:text-stone-900 flex items-center font-bold"
        >
          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"/></svg>
          Back to Selection
        </button>
        <h2 className="text-3xl font-bold mb-10 serif">Payment Details</h2>
        <form onSubmit={handlePayment} className="space-y-6">
          <div className="p-8 border border-stone-200 bg-white shadow-xl">
            <div className="mb-6">
              <label className="block text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-3">Cardholder Name</label>
              <input required className="w-full px-5 py-4 border border-stone-100 bg-stone-50 focus:outline-none focus:border-amber-800 text-sm font-medium" placeholder="M. EDSON" />
            </div>
            <div className="mb-6">
              <label className="block text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-3">Card Number</label>
              <input 
                required 
                maxLength={19}
                className="w-full px-5 py-4 border border-stone-100 bg-stone-50 focus:outline-none focus:border-amber-800 text-sm font-mono tracking-widest" 
                placeholder="**** **** **** ****"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-3">Expiry</label>
                <input required className="w-full px-5 py-4 border border-stone-100 bg-stone-50 focus:outline-none focus:border-amber-800 text-sm" placeholder="MM / YY" />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-3">CVC</label>
                <input required maxLength={4} className="w-full px-5 py-4 border border-stone-100 bg-stone-50 focus:outline-none focus:border-amber-800 text-sm" placeholder="***" />
              </div>
            </div>
          </div>
          <div className="text-center p-4">
            <p className="text-[10px] text-stone-400 mb-8 italic uppercase tracking-widest font-bold">Secure encryption by Edson Digital Security</p>
            <button 
              type="submit"
              className="w-full py-6 bg-stone-900 text-white text-[11px] font-bold uppercase tracking-[0.4em] hover:bg-stone-800 transition-all shadow-2xl"
            >
              Confirm & Pay ${total.toFixed(2)}
            </button>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto py-12 px-6">
      <h2 className="text-4xl font-bold mb-16 text-center serif italic">Your Curated Selection</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
        <div className="lg:col-span-2 space-y-10">
          {items.map(item => (
            <div key={item.id} className="flex items-start space-x-8 pb-10 border-b border-stone-100">
              <div className="w-32 h-40 bg-stone-100 flex-shrink-0 group relative overflow-hidden">
                <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
              </div>
              <div className="flex-grow">
                <div className="flex justify-between mb-2">
                  <h3 className="font-bold text-xl serif italic">{item.name}</h3>
                  <span className="font-semibold text-stone-900 text-lg">${(item.price * item.quantity).toFixed(2)}</span>
                </div>
                <p className="text-stone-400 text-[9px] uppercase tracking-[0.3em] mb-6 font-bold">{item.category}</p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 border border-stone-200 px-4 py-2 bg-white">
                    <button onClick={() => onUpdateQty(item.id, -1)} className="text-stone-400 hover:text-stone-900 text-lg">-</button>
                    <span className="text-xs font-bold w-6 text-center">{item.quantity}</span>
                    <button onClick={() => onUpdateQty(item.id, 1)} className="text-stone-400 hover:text-stone-900 text-lg">+</button>
                  </div>
                  <button 
                    onClick={() => onRemove(item.id)}
                    className="text-stone-400 hover:text-red-900 text-[10px] uppercase tracking-[0.2em] font-bold transition-all border-b border-stone-200 hover:border-red-900"
                  >
                    Remove
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="space-y-8">
          <div className="bg-stone-900 p-10 text-white shadow-2xl sticky top-32">
            <h3 className="text-xs uppercase tracking-[0.4em] font-bold text-amber-500 mb-10 border-b border-stone-800 pb-4">Order Summary</h3>
            <div className="space-y-6 mb-10">
              <div className="flex justify-between text-stone-400 text-[10px] uppercase tracking-widest font-bold">
                <span>Subtotal</span>
                <span>${total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-stone-400 text-[10px] uppercase tracking-widest font-bold">
                <span>Express Delivery</span>
                <span className="text-amber-500">Complimentary</span>
              </div>
              <div className="pt-6 border-t border-stone-800 flex justify-between text-white text-3xl font-bold serif">
                <span>Total</span>
                <span className="text-amber-500">${total.toFixed(2)}</span>
              </div>
            </div>
            <button 
              onClick={() => setStep('payment')}
              className="w-full py-5 bg-amber-800 text-white text-[11px] font-bold uppercase tracking-[0.4em] hover:bg-amber-700 transition-colors shadow-lg"
            >
              Continue to Payment
            </button>
            <p className="text-[9px] text-stone-500 mt-8 text-center uppercase tracking-widest leading-relaxed">
              Shipping from our Paris Atelier.<br/>Estimated Arrival: 48 Hours.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
