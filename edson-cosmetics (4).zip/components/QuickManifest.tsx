
import React, { useState, useRef } from 'react';
import { Product, Category } from '../types';
import { DEFAULT_MASTER_KEY } from '../constants';

interface QuickManifestProps {
  onClose: () => void;
  onAddProduct: (product: Product) => void;
  isAuthorized: boolean;
  onSetAuthorized: (auth: boolean) => void;
}

const QuickManifest: React.FC<QuickManifestProps> = ({ 
  onClose, 
  onAddProduct, 
  isAuthorized, 
  onSetAuthorized 
}) => {
  const [masterKeyInput, setMasterKeyInput] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: 0,
    category: 'Skincare' as Category,
    imageUrl: '',
    ingredients: '',
    usage: '',
    origin: ''
  });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    const storedKey = localStorage.getItem('edson_master_key') || DEFAULT_MASTER_KEY;
    if (masterKeyInput.toUpperCase() === storedKey.toUpperCase()) {
      onSetAuthorized(true);
    } else {
      alert('Vault Key Mismatch. Access Denied.');
      setMasterKeyInput('');
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, imageUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newProduct: Product = {
      ...formData,
      id: `q-${Date.now()}`,
      basePrice: formData.price,
      isService: formData.category === 'Service',
      imageUrl: formData.imageUrl || `https://picsum.photos/seed/${Date.now()}/800/800`,
      badge: 'Boutique Exclusive'
    };
    onAddProduct(newProduct);
    alert('Formulation secured in Boutique.');
    onClose();
  };

  if (!isAuthorized) {
    return (
      <div className="fixed inset-0 z-[110] bg-stone-950/95 backdrop-blur-xl flex items-center justify-center p-6 animate-in fade-in duration-500">
        <div className="max-w-md w-full bg-stone-900 p-12 border border-amber-900/40 relative">
          <button onClick={onClose} className="absolute top-6 right-6 text-stone-500 hover:text-white transition-colors">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
          
          <div className="text-center mb-10">
            <div className="w-16 h-16 bg-amber-900/30 rounded-full flex items-center justify-center mx-auto mb-6 border border-amber-600/20">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
            </div>
            <h3 className="text-2xl font-bold text-white serif mb-2">Encrypted Entry</h3>
            <p className="text-[9px] text-amber-600 uppercase tracking-[0.4em] font-bold">Authorized Personnel Only</p>
          </div>

          <form onSubmit={handleAuth} className="space-y-6">
            <input 
              type="password"
              placeholder="MASTER VAULT KEY"
              className="w-full bg-stone-950 border border-stone-800 px-6 py-5 text-center text-white tracking-[1em] focus:outline-none focus:border-amber-800 transition-all text-sm font-mono placeholder:tracking-normal placeholder:font-sans"
              value={masterKeyInput}
              onChange={e => setMasterKeyInput(e.target.value)}
              autoFocus
            />
            <button className="w-full py-5 bg-amber-800 text-white text-[10px] font-bold uppercase tracking-[0.4em] hover:bg-amber-700 transition-all shadow-2xl">
              Decrypt Manifest Form
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[110] bg-stone-950/80 backdrop-blur-md flex items-center justify-center p-6 animate-in zoom-in-95 duration-500">
      <div className="max-w-4xl w-full bg-white shadow-2xl overflow-hidden relative border border-stone-200">
        <button onClick={onClose} className="absolute top-6 right-6 z-10 text-stone-400 hover:text-amber-800 transition-colors">
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          <div className="bg-stone-50 p-12 border-r border-stone-100 flex flex-col">
            <h3 className="text-3xl font-bold serif italic mb-4">Quick Manifestation</h3>
            <p className="text-[10px] text-amber-800 uppercase tracking-[0.4em] font-bold mb-10">Add a new legacy item to the collection</p>
            
            <div className="flex-grow flex items-center justify-center bg-stone-100 border-2 border-dashed border-stone-200 rounded-sm overflow-hidden mb-8 group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
              {formData.imageUrl ? (
                <img src={formData.imageUrl} className="w-full h-full object-cover" alt="Uploaded" />
              ) : (
                <div className="text-center p-10 group-hover:scale-110 transition-transform">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-stone-300 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  <p className="text-[9px] text-stone-400 font-bold uppercase tracking-widest">Select Visual Essence</p>
                </div>
              )}
              <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageUpload} />
            </div>

            <div className="bg-amber-50 p-6 border border-amber-100/50">
              <p className="text-[10px] text-amber-800/60 leading-relaxed italic">
                "Speed in manifestation is the mark of a true master. Ensure the narrative matches the biological intensity."
              </p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="p-12 space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div className="col-span-2">
                <label className="block text-[9px] font-bold text-stone-400 uppercase tracking-widest mb-2">Formulation Name</label>
                <input required className="w-full px-6 py-4 bg-stone-50 border border-stone-100 focus:outline-none focus:border-amber-800 text-sm italic" placeholder="e.g. Lunar Charcoal Cleanser" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
              </div>
              <div>
                <label className="block text-[9px] font-bold text-stone-400 uppercase tracking-widest mb-2">Investment ($)</label>
                <input type="number" required className="w-full px-6 py-4 bg-stone-50 border border-stone-100 focus:outline-none focus:border-amber-800 text-sm font-mono" value={formData.price} onChange={e => setFormData({...formData, price: Number(e.target.value)})} />
              </div>
              <div>
                <label className="block text-[9px] font-bold text-stone-400 uppercase tracking-widest mb-2">Category</label>
                <select className="w-full px-6 py-4 bg-stone-50 border border-stone-100 focus:outline-none focus:border-amber-800 text-[10px] font-bold uppercase" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value as Category})}>
                  <option value="Skincare">Skincare</option>
                  <option value="Makeup">Makeup</option>
                  <option value="Fragrance">Fragrance</option>
                  <option value="Service">Service</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block text-[9px] font-bold text-stone-400 uppercase tracking-widest mb-2">The Narrative</label>
              <textarea required rows={3} className="w-full px-6 py-4 bg-stone-50 border border-stone-100 focus:outline-none focus:border-amber-800 text-sm italic" placeholder="The story behind the formula..." value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
            </div>
            <div>
              <label className="block text-[9px] font-bold text-stone-400 uppercase tracking-widest mb-2">Core Ingredients</label>
              <input className="w-full px-6 py-4 bg-stone-50 border border-stone-100 focus:outline-none focus:border-amber-800 text-xs" placeholder="Rare botanicals, minerals..." value={formData.ingredients} onChange={e => setFormData({...formData, ingredients: e.target.value})} />
            </div>
            
            <button type="submit" className="w-full py-6 bg-stone-900 text-white text-[10px] font-bold uppercase tracking-[0.4em] hover:bg-amber-800 shadow-xl transition-all">Manifest Formulation</button>
            <p className="text-[8px] text-stone-400 text-center uppercase tracking-widest">Secured by Master Encryption Protocol</p>
          </form>
        </div>
      </div>
    </div>
  );
};

export default QuickManifest;
