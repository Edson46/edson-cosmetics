
import React, { useState, useRef, useEffect } from 'react';
import { Product, Category, SiteConfig, AtelierUpdate, SiteModules } from '../types';
import { generateProductIdea, generateProductVisual } from '../services/geminiService';
import { DEFAULT_MASTER_KEY } from '../constants';

interface AdminPanelProps {
  products: Product[];
  onAddProduct: (product: Product) => void;
  onUpdateProduct: (id: string, updates: Partial<Product>) => void;
  onDeleteProduct: (id: string) => void;
  updates: AtelierUpdate[];
  onAddUpdate: (update: AtelierUpdate) => void;
  onDeleteUpdate: (id: string) => void;
  siteConfig: SiteConfig;
  onUpdateConfig: (config: SiteConfig) => void;
  isMasterAuthorized: boolean;
  onSetMasterAuthorized: (auth: boolean) => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ 
  products, 
  onAddProduct, 
  onUpdateProduct,
  onDeleteProduct,
  updates,
  onAddUpdate,
  onDeleteUpdate,
  siteConfig,
  onUpdateConfig,
  isMasterAuthorized,
  onSetMasterAuthorized
}) => {
  const [masterKeyInput, setMasterKeyInput] = useState('');
  const [activeTab, setActiveTab] = useState<'single' | 'inventory' | 'journal' | 'site' | 'ai' | 'maintenance'>('single');
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [topic, setTopic] = useState('');
  const [draftedConcept, setDraftedConcept] = useState<Product | null>(null);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [newKeyInput, setNewKeyInput] = useState('');

  // Journal Manifestation State
  const [journalForm, setJournalForm] = useState({ headline: '', content: '' });

  const [manualForm, setManualForm] = useState({
    name: '', description: '', price: 0, category: 'Skincare' as Category, imageUrl: '', ingredients: '', usage: '', origin: ''
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    const storedKey = localStorage.getItem('edson_master_key') || DEFAULT_MASTER_KEY;
    if (masterKeyInput.toUpperCase() === storedKey.toUpperCase()) {
      onSetMasterAuthorized(true);
    } else {
      setMasterKeyInput('');
    }
  };

  const handleJournalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newUpdate: AtelierUpdate = {
      id: `u-${Date.now()}`,
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).toUpperCase(),
      headline: journalForm.headline,
      content: journalForm.content,
      isPriority: true
    };
    onAddUpdate(newUpdate);
    setJournalForm({ headline: '', content: '' });
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingProduct) {
      onUpdateProduct(editingProduct.id, editingProduct);
      setEditingProduct(null);
      setActiveTab('inventory');
    } else {
      const newProduct: Product = {
        ...manualForm,
        id: `m-${Date.now()}`,
        basePrice: manualForm.price,
        isService: manualForm.category === 'Service',
        imageUrl: manualForm.imageUrl || `https://picsum.photos/seed/${Date.now()}/800/800`,
        price: manualForm.price
      };
      onAddProduct(newProduct);
      setManualForm({ name: '', description: '', price: 0, category: 'Skincare', imageUrl: '', ingredients: '', usage: '', origin: '' });
    }
  };

  if (!isMasterAuthorized) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center px-6 animate-in fade-in zoom-in duration-1000">
        <div className="max-w-md w-full bg-stone-950 p-20 text-center shadow-[0_50px_150px_rgba(0,0,0,0.9)] border border-amber-900/40 rounded-sm">
          <div className="w-28 h-28 bg-stone-900 rounded-full flex items-center justify-center mx-auto mb-12 border border-amber-500/20 shadow-inner">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h2 className="text-4xl font-bold text-white mb-6 serif">The Vault</h2>
          <p className="text-amber-600 text-[11px] uppercase tracking-[0.6em] font-bold mb-16 italic">Authorized Owner Access</p>
          <form onSubmit={handleAuth} className="space-y-10">
            <input 
              type="password"
              placeholder="ENTER MASTER KEY"
              className="w-full bg-stone-900/50 border border-stone-800 px-8 py-6 text-center text-white tracking-[1.5em] focus:outline-none focus:border-amber-800 transition-all font-mono text-base placeholder:tracking-normal placeholder:font-sans"
              value={masterKeyInput}
              onChange={e => setMasterKeyInput(e.target.value)}
              autoFocus
            />
            <button className="w-full py-6 bg-amber-800 text-white text-[11px] font-bold uppercase tracking-[0.6em] hover:bg-amber-700 transition-all shadow-2xl active:scale-95">
              Unlock Portal
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto py-24 px-6 animate-in fade-in duration-1000">
      <header className="mb-20 flex flex-col lg:flex-row lg:items-end lg:justify-between border-b border-stone-200 pb-16">
        <div>
          <h2 className="text-7xl font-bold text-stone-900 mb-4 serif">The Vault</h2>
          <p className="text-amber-800 uppercase tracking-[0.6em] text-[11px] font-bold italic">Global Boutique Management Interface</p>
        </div>
        <div className="flex flex-wrap gap-4 mt-12 lg:mt-0">
          {[
            { id: 'single', label: 'Manifest Formulation' },
            { id: 'inventory', label: 'Legacy Inventory' },
            { id: 'journal', label: 'Atelier Journal' },
            { id: 'site', label: 'Module Control' },
            { id: 'ai', label: 'AI Synthesis' }
          ].map(tab => (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-10 py-5 text-[10px] font-bold uppercase tracking-[0.4em] border transition-all rounded-full shadow-sm ${activeTab === tab.id ? 'bg-stone-950 text-white border-stone-950 scale-110 shadow-xl' : 'bg-white text-stone-400 border-stone-200 hover:border-amber-800 hover:text-amber-800'}`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </header>

      <div className="bg-white p-16 shadow-2xl border border-stone-100 rounded-sm relative overflow-hidden">
        
        {activeTab === 'single' && (
          <div className="animate-in fade-in slide-in-from-left-8 duration-700">
            <h3 className="text-5xl font-bold serif italic mb-16 border-l-8 border-amber-800 pl-10">New Manifestation</h3>
            <form onSubmit={handleManualSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-20">
              <div className="space-y-10">
                <div>
                  <label className="block text-[10px] font-bold text-stone-400 uppercase tracking-[0.5em] mb-4">Product Identity</label>
                  <input required placeholder="e.g. Celestial Serum No. 4" className="w-full px-8 py-6 border border-stone-100 bg-stone-50 focus:outline-none focus:border-amber-800 text-base italic shadow-inner" 
                    value={manualForm.name} onChange={e => setManualForm({...manualForm, name: e.target.value})} 
                  />
                </div>
                <div className="grid grid-cols-2 gap-10">
                  <div>
                    <label className="block text-[10px] font-bold text-stone-400 uppercase tracking-[0.5em] mb-4">Valuation ($)</label>
                    <input type="number" required className="w-full px-8 py-6 border border-stone-100 bg-stone-50 focus:outline-none focus:border-amber-800 text-base font-mono shadow-inner" 
                      value={manualForm.price} onChange={e => setManualForm({...manualForm, price: Number(e.target.value)})} 
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-stone-400 uppercase tracking-[0.5em] mb-4">Collection</label>
                    <select className="w-full px-8 py-6 border border-stone-100 bg-stone-50 focus:outline-none focus:border-amber-800 text-[10px] font-bold uppercase tracking-[0.3em] shadow-inner" 
                      value={manualForm.category} onChange={e => setManualForm({...manualForm, category: e.target.value as Category})}>
                      <option value="Skincare">Skincare</option>
                      <option value="Makeup">Makeup</option>
                      <option value="Fragrance">Fragrance</option>
                      <option value="Service">Service Ritual</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-stone-400 uppercase tracking-[0.5em] mb-4">Visual Essence (URL)</label>
                  <input placeholder="Image source..." className="w-full px-8 py-6 border border-stone-100 bg-stone-50 focus:outline-none focus:border-amber-800 text-sm shadow-inner" 
                    value={manualForm.imageUrl} onChange={e => setManualForm({...manualForm, imageUrl: e.target.value})} 
                  />
                </div>
              </div>
              
              <div className="space-y-10 flex flex-col">
                <div>
                  <label className="block text-[10px] font-bold text-stone-400 uppercase tracking-[0.5em] mb-4">Philosophical Narrative</label>
                  <textarea required rows={5} placeholder="Describe the soul of this formulation..." className="w-full px-8 py-6 border border-stone-100 bg-stone-50 focus:outline-none focus:border-amber-800 text-base italic leading-relaxed shadow-inner" 
                    value={manualForm.description} onChange={e => setManualForm({...manualForm, description: e.target.value})} 
                  />
                </div>
                <button type="submit" className="w-full py-8 bg-stone-950 text-white text-[12px] font-bold uppercase tracking-[0.6em] hover:bg-amber-800 transition-all shadow-2xl mt-auto">
                  Manifest formulation
                </button>
              </div>
            </form>
          </div>
        )}

        {activeTab === 'inventory' && (
          <div className="animate-in fade-in duration-700">
            <h3 className="text-5xl font-bold serif italic mb-16 border-l-8 border-amber-800 pl-10">Archive Management</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-stone-100 text-[11px] font-bold uppercase tracking-[0.5em] text-stone-400">
                    <th className="pb-8">Identity</th>
                    <th className="pb-8">Classification</th>
                    <th className="pb-8">Current Valuation</th>
                    <th className="pb-8 text-right">Ritual Control</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-50">
                  {products.map(p => (
                    <tr key={p.id} className="group hover:bg-stone-50/50 transition-all">
                      <td className="py-10">
                        <div className="flex items-center space-x-8">
                          <div className="w-20 h-20 bg-stone-100 overflow-hidden shadow-inner border border-stone-200">
                            <img src={p.imageUrl} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700" alt="" />
                          </div>
                          <div>
                            <p className="font-bold text-stone-900 serif text-2xl mb-1">{p.name}</p>
                            <p className="text-[11px] text-stone-300 italic line-clamp-1">{p.description}</p>
                          </div>
                        </div>
                      </td>
                      <td className="py-10">
                        <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-amber-800 bg-amber-50 px-4 py-1.5 rounded-full border border-amber-100">{p.category}</span>
                      </td>
                      <td className="py-10 font-mono text-xl font-medium tracking-tighter">${p.price.toFixed(2)}</td>
                      <td className="py-10 text-right">
                        <button onClick={() => onDeleteProduct(p.id)} className="text-[11px] font-bold uppercase tracking-[0.4em] text-red-800 hover:text-red-500 transition-all border-b border-transparent hover:border-red-500 pb-1">Purge</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'journal' && (
          <div className="animate-in fade-in slide-in-from-right-8 duration-700">
            <h3 className="text-5xl font-bold serif italic mb-16 border-l-8 border-amber-800 pl-10">Atelier Journal Manifestation</h3>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
              <form onSubmit={handleJournalSubmit} className="space-y-10">
                <div>
                  <label className="block text-[11px] font-bold text-stone-400 uppercase tracking-[0.5em] mb-4">Update Headline</label>
                  <input required placeholder="New feature or announcement..." className="w-full px-8 py-6 border border-stone-100 bg-stone-50 focus:outline-none focus:border-amber-800 text-2xl serif italic shadow-inner" 
                    value={journalForm.headline} onChange={e => setJournalForm({ ...journalForm, headline: e.target.value })} 
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-stone-400 uppercase tracking-[0.5em] mb-4">Detailed Narrative</label>
                  <textarea required rows={6} placeholder="Expand on the manifestation..." className="w-full px-8 py-6 border border-stone-100 bg-stone-50 focus:outline-none focus:border-amber-800 text-base leading-relaxed italic shadow-inner" 
                    value={journalForm.content} onChange={e => setJournalForm({ ...journalForm, content: e.target.value })} 
                  />
                </div>
                <button type="submit" className="w-full py-8 bg-stone-900 text-white text-[12px] font-bold uppercase tracking-[0.6em] hover:bg-amber-800 shadow-2xl transition-all">Manifest Journal Entry</button>
              </form>
              
              <div className="space-y-8">
                <h4 className="text-[11px] uppercase tracking-[0.5em] font-bold text-stone-300 border-b border-stone-100 pb-4">Manifested Archives</h4>
                <div className="space-y-6 max-h-[600px] overflow-y-auto pr-6 custom-scrollbar">
                  {updates.map(u => (
                    <div key={u.id} className="p-8 border border-stone-100 bg-stone-50 group hover:bg-white transition-all shadow-sm">
                      <div className="flex justify-between items-start mb-6">
                        <span className="text-[10px] font-bold text-amber-800 uppercase tracking-widest">{u.date}</span>
                        <button onClick={() => onDeleteUpdate(u.id)} className="text-[10px] font-bold text-red-800 uppercase opacity-0 group-hover:opacity-100 transition-opacity">Purge</button>
                      </div>
                      <h5 className="text-2xl font-bold serif italic mb-4">{u.headline}</h5>
                      <p className="text-sm text-stone-400 italic line-clamp-3 leading-loose">{u.content}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'site' && (
          <div className="animate-in fade-in duration-700 max-w-4xl">
            <h3 className="text-5xl font-bold serif italic mb-16 border-l-8 border-amber-800 pl-10">Site Modules</h3>
            <div className="space-y-10">
              {[
                { id: 'aiAdvisor', label: 'Edson Private Advisor', desc: 'Synthesized intelligence for client inquiries.' },
                { id: 'virtualTryOn', label: 'Virtual AR Try-On', desc: 'Real-time pigment simulation for client cameras.' },
                { id: 'liveValuation', label: 'Market Scarcity Logic', desc: 'Simulates botanical extraction market prices.' },
                { id: 'journal', label: 'Atelier Journal', desc: 'Broadcasting platform for site updates.' }
              ].map(mod => (
                <div key={mod.id} className="flex items-center justify-between p-10 bg-stone-50 border border-stone-100 shadow-inner group">
                  <div>
                    <p className="text-[12px] font-bold uppercase tracking-[0.3em] text-stone-900 group-hover:text-amber-800 transition-colors">{mod.label}</p>
                    <p className="text-[11px] text-stone-400 italic mt-2">{mod.desc}</p>
                  </div>
                  <button 
                    onClick={() => onUpdateConfig({ ...siteConfig, modules: { ...siteConfig.modules, [mod.id]: !siteConfig.modules[mod.id as keyof SiteModules] } })}
                    className={`w-16 h-8 rounded-full transition-all relative ${siteConfig.modules[mod.id as keyof SiteModules] ? 'bg-amber-800 shadow-xl' : 'bg-stone-200'}`}
                  >
                    <span className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-all shadow-md ${siteConfig.modules[mod.id as keyof SiteModules] ? 'right-1' : 'left-1'}`}></span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminPanel;
