
import React from 'react';
import { View, SiteModules } from '../types';

interface NavbarProps {
  currentView: View;
  setView: (view: View) => void;
  cartCount: number;
  modules: SiteModules;
}

const Navbar: React.FC<NavbarProps> = ({ currentView, setView, cartCount, modules }) => {
  return (
    <nav className="sticky top-0 z-50 glass px-6 py-4 flex items-center justify-between border-b border-stone-200">
      <div 
        className="flex items-center space-x-3 cursor-pointer group" 
        onClick={() => setView(View.SHOP)}
      >
        <div className="relative w-10 h-10 rounded-full overflow-hidden border-2 border-amber-800 shadow-sm transition-transform group-hover:scale-110">
          <img 
            src="https://raw.githubusercontent.com/fedelebron/edson-assets/main/edson-founder.jpg" 
            alt="Edson Founder" 
            className="w-full h-full object-cover object-top grayscale-[0.2] contrast-[1.1]"
            onError={(e) => {
              (e.target as HTMLImageElement).style.display = 'none';
              (e.target as any).parentElement.innerHTML = '<div class="w-full h-full bg-stone-900 flex items-center justify-center text-amber-500 font-bold text-xs">E</div>';
            }}
          />
        </div>
        <div className="text-2xl font-bold tracking-tighter text-stone-900">
          <span className="text-amber-800">EDSON</span><span className="font-light">COSMETICS</span>
        </div>
      </div>
      
      <div className="hidden lg:flex space-x-10 text-[11px] font-bold uppercase tracking-[0.3em] text-stone-500">
        <button 
          onClick={() => setView(View.SHOP)}
          className={`hover:text-amber-800 transition-colors ${currentView === View.SHOP ? 'text-stone-900 border-b-2 border-amber-800 pb-1' : ''}`}
        >
          Boutique
        </button>
        <button 
          onClick={() => setView(View.SERVICES)}
          className={`hover:text-amber-800 transition-colors ${currentView === View.SERVICES ? 'text-stone-900 border-b-2 border-amber-800 pb-1' : ''}`}
        >
          Atelier Services
        </button>
        
        {modules.aiAdvisor && (
          <button 
            onClick={() => setView(View.EDSON_ADVISOR)}
            className={`hover:text-amber-800 transition-colors ${currentView === View.EDSON_ADVISOR ? 'text-stone-900 border-b-2 border-amber-800 pb-1' : ''}`}
          >
            Edson Advisor
          </button>
        )}

        <button 
          onClick={() => setView(View.ADMIN)}
          className={`flex items-center space-x-2 hover:text-amber-800 transition-colors ${currentView === View.ADMIN ? 'text-stone-900 border-b-2 border-amber-800 pb-1' : ''}`}
        >
          <span>The Vault</span>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
          </svg>
        </button>
      </div>

      <div className="flex items-center space-x-6">
        <button 
          onClick={() => setView(View.PROFILE)}
          className={`p-2 transition-colors ${currentView === View.PROFILE ? 'text-amber-800' : 'text-stone-700 hover:text-amber-800'}`}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
          </svg>
        </button>

        <button 
          onClick={() => setView(View.CART)}
          className="relative p-2 text-stone-700 hover:text-amber-800 transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
          </svg>
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-amber-800 text-white text-[9px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
              {cartCount}
            </span>
          )}
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
