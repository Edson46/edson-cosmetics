
import { Product, AtelierUpdate } from './types';

export const DEFAULT_MASTER_KEY = 'EDSON1994';

export const INITIAL_UPDATES: AtelierUpdate[] = [
  {
    id: 'u1',
    date: 'OCT 24, 2024',
    headline: 'Introduction of Live Valuation',
    content: 'Our boutique now features a proprietary Live Valuation algorithm. Prices of rare formulations now fluctuate based on the scarcity of botanical extracts globally.',
    isPriority: true
  },
  {
    id: 'u2',
    date: 'SEP 12, 2024',
    headline: 'The Vault is Now Open',
    content: 'Master formulators can now manifest new products and rituals directly through the secure Edson Vault encryption protocol.',
    isPriority: false
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'e1',
    name: 'Oud Noir Eau de Parfum',
    description: 'A deep, mysterious fragrance with notes of rare agarwood, leather, and warm amber.',
    basePrice: 185,
    price: 185,
    category: 'Fragrance',
    imageUrl: 'https://images.unsplash.com/photo-1541643600914-78b084683601?auto=format&fit=crop&q=80&w=800',
    isService: false,
    rating: 4.9,
    reviewsCount: 124,
    badge: 'Limited Edition',
    ingredients: 'Alcohol Denat, Parfum, Agarwood (Oud) Essence, Leather Accord, Labdanum, Patchouli, Pink Pepper.',
    usage: 'Mist onto pulse points—neck, wrists, and behind the ears. Avoid rubbing to preserve the scent architecture.',
    origin: 'Distilled and matured in the Grasse region of France, utilizing sustainably harvested oud from Southeast Asia.'
  },
  {
    id: 's2',
    name: 'Jelly Skin Bouncy Hydrator',
    description: 'A revolutionary high-viscosity hydro-gel that creates a "glass-skin" effect, locking in deep moisture for a plump, youthful bounce.',
    basePrice: 65,
    price: 65,
    category: 'Skincare',
    imageUrl: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?auto=format&fit=crop&q=80&w=800',
    isService: false,
    rating: 5.0,
    reviewsCount: 88,
    badge: 'Must Have',
    ingredients: 'Low-molecular Hyaluronic Acid, Fermented Camellia Seed Oil, Polyglutamic Acid, Birch Sap Extract.',
    usage: 'Apply a dime-sized amount to damp skin. Pat gently until absorbed to activate the bouncy gel network.',
    origin: 'Synthesized in our Tokyo Laboratory using cold-extraction methods to preserve biological potency.'
  },
  {
    id: 'f3',
    name: 'Celestial Hair Mist',
    description: 'A protective hair perfume enriched with silk proteins. Leaves a subtle trail of White Amber and Moonflower while protecting against environmental stress.',
    basePrice: 75,
    price: 75,
    category: 'Fragrance',
    imageUrl: 'https://images.unsplash.com/photo-1615485242125-9988b776269b?auto=format&fit=crop&q=80&w=800',
    isService: false,
    rating: 4.8,
    reviewsCount: 156,
    ingredients: 'Hydrolyzed Silk, Panthenol, Moonflower Extract, White Amber Resin, Vitamin E.',
    usage: 'Spray onto hair from a distance of 30cm. Can be used on dry hair throughout the day for refreshment.',
    origin: 'Formulated in partnership with Swiss master perfumers and hair biologists.'
  },
  {
    id: 's1',
    name: 'Skin Grow Biological Soap',
    description: 'Artisanal cold-pressed soap infused with botanical stem cells to accelerate cellular renewal and reveal a polished, radiant texture.',
    basePrice: 45,
    price: 45,
    category: 'Skincare',
    imageUrl: 'https://images.unsplash.com/photo-1600857062241-98e5dba7f214?auto=format&fit=crop&q=80&w=800',
    isService: false,
    rating: 4.9,
    reviewsCount: 312,
    badge: 'New Arrival',
    ingredients: 'Saponified Olive and Coconut Oils, Swiss Apple Stem Cells, Niacinamide, Squalane, French Pink Clay.',
    usage: 'Work into a rich lather between palms. Massage onto face for 60 seconds before rinsing with cool water.',
    origin: 'Crafted in small batches at our South of France atelier.'
  },
  {
    id: 'e2',
    name: 'Petals of Edson',
    description: 'A delicate floral bouquet of damask rose and peony, brightened by bergamot.',
    basePrice: 145,
    price: 145,
    category: 'Fragrance',
    imageUrl: 'https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&q=80&w=800',
    isService: false,
    rating: 4.7,
    reviewsCount: 89,
    ingredients: 'Damask Rose Absolute, Peony Accord, Italian Bergamot, White Musk, Cedarwood.',
    usage: 'Spray liberally over the body or into your hair for a lasting floral signature.',
    origin: 'The roses are hand-picked at dawn in the Valley of Roses, Bulgaria.'
  },
  {
    id: '1',
    name: 'Midnight Radiance Serum',
    description: 'A transformative nocturnal treatment that restores your natural glow while you sleep.',
    basePrice: 85,
    price: 85,
    category: 'Skincare',
    imageUrl: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=800',
    isService: false,
    rating: 4.8,
    reviewsCount: 450,
    badge: 'Bestseller',
    ingredients: 'Encapsulated Retinol, Peptides, Resveratrol, Melatonin, Evening Primrose Oil.',
    usage: 'Apply 2-3 drops after cleansing. Follow with a night cream. Use only at night.',
    origin: 'Developed in our New York Innovation Center.'
  },
  {
    id: '2',
    name: 'Velvet Rose Lipstick',
    description: 'A matte yet moisturizing formula in a classic deep crimson hue.',
    basePrice: 32,
    price: 32,
    category: 'Makeup',
    imageUrl: 'https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&q=80&w=800',
    isService: false,
    rating: 4.6,
    reviewsCount: 210,
    ingredients: 'Candelilla Wax, Jojoba Esters, Velvet Rose Pigment, Hyaluronic Filling Spheres.',
    usage: 'Apply directly to lips starting from the center and moving outwards. Layer for intensity.',
    origin: 'Pigments sourced from historic mineral mines in Tuscany.'
  }
];
