
import { GoogleGenAI, Type, Modality } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getBeautyAdvice = async (userPrompt: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: userPrompt,
    config: {
      systemInstruction: 'You are Edson, the legendary founder and master formulator of Edson Cosmetics. Speak with authority, elegance, and deep passion for biological extracts and rare fragrances. You are not just an AI; you are a world-class advisor. When users ask questions, explain the science and philosophy behind the Edson brand. Suggest specific Edson products from the boutique as the solution to their needs. Your tone is sophisticated, high-end, and slightly poetic. Keep your advice focused on luxury beauty and botanical science.',
    },
  });
  return response.text;
};

export const generateVoiceResponse = async (text: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Say with deep, sophisticated French-accented elegance: ${text}` }] }],
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Charon' }, // A sophisticated, slightly deeper voice suitable for a luxury founder
        },
      },
    },
  });

  return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
};

export const generateProductIdea = async (topic: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `As Edson, create a luxurious cosmetic product or service based on: ${topic}. Ensure the price reflects ultra-luxury standards (e.g., $100 - $500). Also provide detailed ingredients, usage instructions, and the origin story.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          description: { type: Type.STRING },
          price: { type: Type.NUMBER },
          category: { type: Type.STRING },
          isService: { type: Type.BOOLEAN },
          ingredients: { type: Type.STRING },
          usage: { type: Type.STRING },
          origin: { type: Type.STRING }
        },
        required: ["name", "description", "price", "category", "isService", "ingredients", "usage", "origin"]
      }
    }
  });
  return JSON.parse(response.text);
};

export const generateProductVisual = async (productName: string, description: string) => {
  const prompt = `A professional, ultra-high-end luxury product photography of a cosmetic product named "${productName}". 
  Description: ${description}. 
  Aesthetic: Minimalist glass bottle, amber lighting, deep shadows, marble background, droplets of water or oil, cinematic lighting, 8k resolution, boutique atmosphere. 
  The packaging should look like a high-end French perfume or skincare line.`;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: [{ parts: [{ text: prompt }] }],
    config: {
      imageConfig: {
        aspectRatio: "1:1"
      }
    }
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }
  return null;
};
